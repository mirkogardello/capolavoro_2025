<?php
session_start();
    include "include/form_aggiungiArtificiale.html";
    if(isset($_POST['nomeArtificiale']) && isset($_POST['tipoArtificiale']) && isset($_POST['descrizioneArtificiale']) && isset($_POST['prezzoArtificiale']) && isset($_POST['urlArtificiale'])){
        $file = fopen("include/artificiali.csv", 'a');
        fwrite($file, $_POST['nomeArtificiale'].";".$_POST['tipoArtificiale'].";".$_POST['descrizioneArtificiale'].";".$_POST['prezzoArtificiale'].";".$_POST['urlArtificiale']);
        fclose($file);
        header("Location: index.php");
    }



    


?>