<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
define('TABELLA_UTENTI','include/utenti.csv');
define('TABELLA_ARTIFICIALI', 'include/artificiali.csv');
?>