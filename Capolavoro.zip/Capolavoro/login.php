<?php
session_start();
require('include/config.php');
if(isset($_POST['username']) && isset($_POST['password'])){
    $username = $_POST['username'];
    $password = $_POST['password'];
    if(!file_exists(TABELLA_UTENTI)){
        die("Non esiste il file");
    }
    $loginOk = false;
    $fileReader = fopen(TABELLA_UTENTI, 'r');
    while(!feof($fileReader) && !$loginOk){
        $riga=fgetcsv($fileReader, 0, ';');
        if($riga[0] == $username && $password == $riga[1]) $loginOk = true;
    }
    if($loginOk){
        $_SESSION['username'] = $username;
        $_SESSION['login'] = true;
    }
    else{
        $_SESSION['username'] = "";
        $_SESSION['login'] = false;
    }
    header("Location: index.php");
}
include"include/form_login.html";


?>