<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ver Scorso AS</title>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/5/w3.css">
    <style>
        .contenitore{
            display: flex;
        }
        .parte{
            /*display: grid;
            grid-template-columns: 1fr 1fr 1fr 1fr;*/
            flex: 1;
        }
        .pulsanti{
            width: 100%;
        }

    </style>
</head>
<body>
    <?php
        session_start();
        include "include/forms_navigazione.html";
        if(isset($_SESSION['arrayInizializzato'])){

        }
        else{
            $_SESSION['prodotti'] = [];
            $_SESSION['arrayInizializzato'] = true;
        }
        if(isset($_SESSION['login']) && $_SESSION['login']===true){
            //echo "<div><form action='logout.php' method='post'><p><input type='submit' placeholder='logout' name='logout'></p></form></div>";
            //echo "<div><form action='logout.php' method='post'><p><button type='submit' id='invia' onclick='this.form.submit()'>LOGOUT</button></p></form></div>";
            include "include/form_navigazione_ACCESSOESEGUITO.html";

        }
        
    ?>    
</body>
</html>