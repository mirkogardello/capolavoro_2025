<?php
session_start();
$rows = [];

if (($handle = fopen('include/artificiali.csv', "r")) !== false) {
    while (($data = fgetcsv($handle,0,  ";")) !== false) {
        $rows[] = $data;
    }
    fclose($handle);
}
echo "<a href='aggiungiNuovoArtificiale.php'>Torna alla pagina di aggiunta</a>";
echo "<div>";
/*
for ($i = 0; $i < count($rows); $i++) {
    echo "<divimg src='".$rows[$i][count($rows[$i])-1]."'></p>";
    echo "</div><br>";
}
    */
for ($i = 0; $i < count($rows); $i++) {
    echo "<div>";
    
    for ($j = 0; $j < count($rows[$i]) - 1; $j++) {
        echo "<p>" . $rows[$i][$j] . "</p>";
    }
    echo("<form action='aggiornaCarrello.php' method='post'><input type='hidden' name='prezzoAggiunta' value=".$rows[$i][2]."><input type='hidden' name='aggiuntaAlCarrello' value='".$rows[$i][0]."'><input type='number' name='quantita' required><button type='submit' onclick='this.form.submit()'>Aggiungi al carrello</button></form>");
    echo "<p><img src='" . $rows[$i][count($rows[$i]) - 1] . "'></p>";

    echo "</div><br>";
}

echo "</div>";
?>