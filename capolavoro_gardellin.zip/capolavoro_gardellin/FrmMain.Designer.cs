﻿namespace capolavoro_gardellin
{
    partial class FrmMain
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblGiocatori = new Label();
            lblPartite = new Label();
            lbxGiocatori = new ListBox();
            lbxPartite = new ListBox();
            btnAggiungiGiocatore = new Button();
            btnRimuoviGiocatori = new Button();
            btnRimettiInGioco = new Button();
            btnGeneraPartite = new Button();
            btnInserisciManualmente = new Button();
            btnRimuoviPartite = new Button();
            btnChiudiPartita = new Button();
            ofdApri = new OpenFileDialog();
            sfdSalva = new SaveFileDialog();
            btnCarica = new Button();
            btnSalva = new Button();
            btnPulisci = new Button();
            btnVisualizzaDatiGiocatore = new Button();
            btnVisualizzaDatiPartita = new Button();
            SuspendLayout();
            // 
            // lblGiocatori
            // 
            lblGiocatori.AutoSize = true;
            lblGiocatori.Font = new Font("Stencil", 30F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblGiocatori.Location = new Point(103, 20);
            lblGiocatori.Name = "lblGiocatori";
            lblGiocatori.Size = new Size(375, 71);
            lblGiocatori.TabIndex = 0;
            lblGiocatori.Text = "GIOCATORI :";
            // 
            // lblPartite
            // 
            lblPartite.AutoSize = true;
            lblPartite.Font = new Font("Stencil", 30F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblPartite.Location = new Point(772, 20);
            lblPartite.Name = "lblPartite";
            lblPartite.Size = new Size(312, 71);
            lblPartite.TabIndex = 1;
            lblPartite.Text = "PARTITE :";
            // 
            // lbxGiocatori
            // 
            lbxGiocatori.FormattingEnabled = true;
            lbxGiocatori.ItemHeight = 25;
            lbxGiocatori.Location = new Point(12, 117);
            lbxGiocatori.Name = "lbxGiocatori";
            lbxGiocatori.SelectionMode = SelectionMode.MultiExtended;
            lbxGiocatori.Size = new Size(600, 629);
            lbxGiocatori.TabIndex = 2;
            // 
            // lbxPartite
            // 
            lbxPartite.FormattingEnabled = true;
            lbxPartite.ItemHeight = 25;
            lbxPartite.Location = new Point(672, 117);
            lbxPartite.Name = "lbxPartite";
            lbxPartite.SelectionMode = SelectionMode.MultiExtended;
            lbxPartite.Size = new Size(600, 629);
            lbxPartite.TabIndex = 3;
            // 
            // btnAggiungiGiocatore
            // 
            btnAggiungiGiocatore.Location = new Point(12, 752);
            btnAggiungiGiocatore.Name = "btnAggiungiGiocatore";
            btnAggiungiGiocatore.Size = new Size(200, 100);
            btnAggiungiGiocatore.TabIndex = 4;
            btnAggiungiGiocatore.Text = "AGGIUNGI GIOCATORE";
            btnAggiungiGiocatore.UseVisualStyleBackColor = true;
            btnAggiungiGiocatore.Click += btnAggiungiGiocatore_Click;
            // 
            // btnRimuoviGiocatori
            // 
            btnRimuoviGiocatori.Location = new Point(212, 752);
            btnRimuoviGiocatori.Name = "btnRimuoviGiocatori";
            btnRimuoviGiocatori.Size = new Size(200, 100);
            btnRimuoviGiocatori.TabIndex = 5;
            btnRimuoviGiocatori.Text = "ELIMINA GIOCATORI";
            btnRimuoviGiocatori.UseVisualStyleBackColor = true;
            btnRimuoviGiocatori.Click += btnRimuoviGiocatore_Click;
            // 
            // btnRimettiInGioco
            // 
            btnRimettiInGioco.Location = new Point(412, 752);
            btnRimettiInGioco.Name = "btnRimettiInGioco";
            btnRimettiInGioco.Size = new Size(200, 100);
            btnRimettiInGioco.TabIndex = 6;
            btnRimettiInGioco.Text = "RIMETTI IN GIOCO";
            btnRimettiInGioco.UseVisualStyleBackColor = true;
            btnRimettiInGioco.Click += btnRimettiInGioco_Click;
            // 
            // btnGeneraPartite
            // 
            btnGeneraPartite.Location = new Point(672, 752);
            btnGeneraPartite.Name = "btnGeneraPartite";
            btnGeneraPartite.Size = new Size(200, 100);
            btnGeneraPartite.TabIndex = 7;
            btnGeneraPartite.Text = "GENERA PARTITE CASUALMENTE";
            btnGeneraPartite.UseVisualStyleBackColor = true;
            btnGeneraPartite.Click += btnGeneraCasuale_Click;
            // 
            // btnInserisciManualmente
            // 
            btnInserisciManualmente.Location = new Point(872, 752);
            btnInserisciManualmente.Name = "btnInserisciManualmente";
            btnInserisciManualmente.Size = new Size(200, 100);
            btnInserisciManualmente.TabIndex = 8;
            btnInserisciManualmente.Text = "INSERISCI MANUALMENTE";
            btnInserisciManualmente.UseVisualStyleBackColor = true;
            btnInserisciManualmente.Click += btnInserisciManualmente_Click;
            // 
            // btnRimuoviPartite
            // 
            btnRimuoviPartite.Location = new Point(1073, 752);
            btnRimuoviPartite.Name = "btnRimuoviPartite";
            btnRimuoviPartite.Size = new Size(200, 100);
            btnRimuoviPartite.TabIndex = 9;
            btnRimuoviPartite.Text = "RIMUOVI PARTITE";
            btnRimuoviPartite.UseVisualStyleBackColor = true;
            btnRimuoviPartite.Click += btnRimuoviPartite_Click;
            // 
            // btnChiudiPartita
            // 
            btnChiudiPartita.Location = new Point(1279, 117);
            btnChiudiPartita.Name = "btnChiudiPartita";
            btnChiudiPartita.Size = new Size(200, 100);
            btnChiudiPartita.TabIndex = 10;
            btnChiudiPartita.Text = "CHIUDI UNA PARTITA";
            btnChiudiPartita.UseVisualStyleBackColor = true;
            btnChiudiPartita.Click += btnChiudiPartita_Click;
            // 
            // btnCarica
            // 
            btnCarica.Location = new Point(1279, 223);
            btnCarica.Name = "btnCarica";
            btnCarica.Size = new Size(200, 100);
            btnCarica.TabIndex = 11;
            btnCarica.Text = "CARICA UN TORNEO DA FILE";
            btnCarica.UseVisualStyleBackColor = true;
            btnCarica.Click += btnCarica_Click;
            // 
            // btnSalva
            // 
            btnSalva.Location = new Point(1279, 329);
            btnSalva.Name = "btnSalva";
            btnSalva.Size = new Size(200, 100);
            btnSalva.TabIndex = 12;
            btnSalva.Text = "SALVA QUESTO TORNEO SU FILE";
            btnSalva.UseVisualStyleBackColor = true;
            btnSalva.Click += btnSalva_Click;
            // 
            // btnPulisci
            // 
            btnPulisci.Location = new Point(1279, 435);
            btnPulisci.Name = "btnPulisci";
            btnPulisci.Size = new Size(200, 100);
            btnPulisci.TabIndex = 13;
            btnPulisci.Text = "PULISCI LE LISTE";
            btnPulisci.UseVisualStyleBackColor = true;
            btnPulisci.Click += btnPulisci_Click;
            // 
            // btnVisualizzaDatiGiocatore
            // 
            btnVisualizzaDatiGiocatore.Location = new Point(1279, 541);
            btnVisualizzaDatiGiocatore.Name = "btnVisualizzaDatiGiocatore";
            btnVisualizzaDatiGiocatore.Size = new Size(200, 100);
            btnVisualizzaDatiGiocatore.TabIndex = 14;
            btnVisualizzaDatiGiocatore.Text = "VISUALIZZA DATI DEL GIOCATORE";
            btnVisualizzaDatiGiocatore.UseVisualStyleBackColor = true;
            btnVisualizzaDatiGiocatore.Click += btnVisualizzaDatiGiocatore_Click;
            // 
            // btnVisualizzaDatiPartita
            // 
            btnVisualizzaDatiPartita.Location = new Point(1279, 647);
            btnVisualizzaDatiPartita.Name = "btnVisualizzaDatiPartita";
            btnVisualizzaDatiPartita.Size = new Size(200, 100);
            btnVisualizzaDatiPartita.TabIndex = 15;
            btnVisualizzaDatiPartita.Text = "VISUALIZZA DATI DELLA PARTITA";
            btnVisualizzaDatiPartita.UseVisualStyleBackColor = true;
            btnVisualizzaDatiPartita.Click += btnVisualizzaDatiPartita_Click;
            // 
            // FrmMain
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.PaleGoldenrod;
            ClientSize = new Size(1490, 866);
            Controls.Add(btnVisualizzaDatiPartita);
            Controls.Add(btnVisualizzaDatiGiocatore);
            Controls.Add(btnPulisci);
            Controls.Add(btnSalva);
            Controls.Add(btnCarica);
            Controls.Add(btnChiudiPartita);
            Controls.Add(btnRimuoviPartite);
            Controls.Add(btnInserisciManualmente);
            Controls.Add(btnGeneraPartite);
            Controls.Add(btnRimettiInGioco);
            Controls.Add(btnRimuoviGiocatori);
            Controls.Add(btnAggiungiGiocatore);
            Controls.Add(lbxPartite);
            Controls.Add(lbxGiocatori);
            Controls.Add(lblPartite);
            Controls.Add(lblGiocatori);
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            Name = "FrmMain";
            Text = "Torneo";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblGiocatori;
        private Label lblPartite;
        private ListBox lbxGiocatori;
        private ListBox lbxPartite;
        private Button btnAggiungiGiocatore;
        private Button btnRimuoviGiocatori;
        private Button btnRimettiInGioco;
        private Button btnGeneraPartite;
        private Button btnInserisciManualmente;
        private Button btnRimuoviPartite;
        private Button btnChiudiPartita;
        private OpenFileDialog ofdApri;
        private SaveFileDialog sfdSalva;
        private Button btnCarica;
        private Button btnSalva;
        private Button btnPulisci;
        private Button btnVisualizzaDatiGiocatore;
        private Button btnVisualizzaDatiPartita;
    }
}
