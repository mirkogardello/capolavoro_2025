﻿namespace capolavoro_gardellin;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;

public class Giocatore
{
    public string Nome { get; set; }
    public string Info { get; set; }
    public bool Stato { get; set; } = true;
    [JsonConstructor]
    public Giocatore(string nome, string info)
    {
        Nome = nome.Trim();
        Info = info.Trim();
    }
    public Giocatore(string nome) : this(nome, "") { }
    public override string ToString()
    {
        string s = $"{Nome}, {StatoToString()}";
        if(!string.IsNullOrEmpty(Info))s += $", {Info}";
        return s;

    }
    public string StatoToString()
    {
        if(Stato)
            return "In gioco";
        else
            return "Eliminato";
    }
    public void CambiaStato(bool b) => Stato = b;


}
public class Partita
{
    public Giocatore g1{get; set; }
    public Giocatore g2 { get; set; }
    public string Risultato { get; private set; } = "In attesa di risultato";
    
    public Partita(Giocatore g1, Giocatore g2)
    {
        if(g1 == g2)throw new ArgumentException("I giocatori non possono essere gli stessi");
        this.g1 = g1;
        this.g2 = g2;
    }
    [JsonConstructor]
    public Partita(Giocatore g1, Giocatore g2, string risultato):this(g1,g2)
    {
        Risultato = risultato.Trim();
    }
    public void CambiaRisultato(int punteggio1, int punteggio2) => Risultato = $"{punteggio1} - {punteggio2}";
    public override string ToString()
    {
        if (Risultato == "In attesa di risultato")
            return $"{g1.Nome} vs {g2.Nome} ({Risultato})";
        else
            return $"{g1.Nome} {Risultato} {g2.Nome}";
    }
}
public class Torneo
{
    public List<Giocatore> giocatori { get; set; }
    public List<Partita> partite { get; set; }
    public Torneo()
    {
        giocatori = new List<Giocatore>();
        partite = new List<Partita>();
    }
    public void AggiungiGiocatore(Giocatore g)
    {
        if (giocatori.Any(x => x.Nome == g.Nome))
            throw new ArgumentException("Giocatore già presente");
        giocatori.Add(g);
    }
    public void AggiungiPartita(Partita p) => partite.Add(p);
    public void RimuoviGiocatore(Giocatore g) => giocatori.Remove(g);
    public void RimuoviPartita(Partita p) => partite.Remove(p);
    public void RimuoviDalGioco(Giocatore g)
    {
        foreach(Giocatore giocatore in giocatori)
        {
            if (giocatore == g)
                giocatore.CambiaStato(false);
        }
    }


}

