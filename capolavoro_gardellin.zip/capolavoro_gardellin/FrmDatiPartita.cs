﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace capolavoro_gardellin;

public partial class FrmDatiPartita : Form
{
    public Partita p;
    public FrmDatiPartita(Partita p)
    {
        InitializeComponent();
        lblGiocatore1.Text = "Giocatore : " + p.g1.Nome;
        lblGiocatore2.Text = "Giocatore : " + p.g2.Nome;
        this.p = p;

    }
}
