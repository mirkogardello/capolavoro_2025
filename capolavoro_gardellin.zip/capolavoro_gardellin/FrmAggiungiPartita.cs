﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace capolavoro_gardellin;

public partial class FrmAggiungiPartita : Form
{
    
    public FrmAggiungiPartita(List<Giocatore> copie)
    {
        InitializeComponent();
        foreach (Giocatore g in copie)
        {
            if (g.Stato)
            {
                lbxScelta1.Items.Add(g);
                lbxScelta2.Items.Add(g);  
            }
        }
    }
}
