﻿namespace capolavoro_gardellin
{
    partial class FrmAggiungiGiocatore
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnOK = new Button();
            lblNome = new Label();
            txtNome = new TextBox();
            lblDescrizione = new Label();
            txtDescrizione = new TextBox();
            SuspendLayout();
            // 
            // btnOK
            // 
            btnOK.DialogResult = DialogResult.OK;
            btnOK.Font = new Font("Elephant", 36F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnOK.Location = new Point(3, 442);
            btnOK.Name = "btnOK";
            btnOK.Size = new Size(772, 100);
            btnOK.TabIndex = 0;
            btnOK.Text = "CONFERMA";
            btnOK.UseVisualStyleBackColor = true;
            // 
            // lblNome
            // 
            lblNome.AutoSize = true;
            lblNome.Font = new Font("Source Sans Pro Black", 20F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblNome.Location = new Point(293, 18);
            lblNome.Name = "lblNome";
            lblNome.Size = new Size(159, 50);
            lblNome.TabIndex = 1;
            lblNome.Text = "NOME : ";
            // 
            // txtNome
            // 
            txtNome.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtNome.Location = new Point(12, 71);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(754, 61);
            txtNome.TabIndex = 3;
            // 
            // lblDescrizione
            // 
            lblDescrizione.AutoSize = true;
            lblDescrizione.Font = new Font("Source Sans Pro Black", 20F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblDescrizione.Location = new Point(232, 153);
            lblDescrizione.Name = "lblDescrizione";
            lblDescrizione.Size = new Size(295, 50);
            lblDescrizione.TabIndex = 4;
            lblDescrizione.Text = "DESCRIZIONE : ";
            // 
            // txtDescrizione
            // 
            txtDescrizione.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtDescrizione.Location = new Point(12, 206);
            txtDescrizione.Multiline = true;
            txtDescrizione.Name = "txtDescrizione";
            txtDescrizione.Size = new Size(754, 213);
            txtDescrizione.TabIndex = 5;
            // 
            // FrmAggiungiGiocatore
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(778, 544);
            Controls.Add(txtDescrizione);
            Controls.Add(lblDescrizione);
            Controls.Add(txtNome);
            Controls.Add(lblNome);
            Controls.Add(btnOK);
            Name = "FrmAggiungiGiocatore";
            Text = "Aggiunta di un giocatore";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnOK;
        private Label lblNome;
        public TextBox txtNome;
        private Label lblDescrizione;
        public TextBox txtDescrizione;
        private TextBox textBox1;
    }
}