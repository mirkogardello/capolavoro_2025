﻿namespace capolavoro_gardellin
{
    partial class FrmDatiPartita
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblGiocatore1 = new Label();
            lblGiocatore2 = new Label();
            btnPartitaOK = new Button();
            nudG1 = new NumericUpDown();
            nudG2 = new NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)nudG1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)nudG2).BeginInit();
            SuspendLayout();
            // 
            // lblGiocatore1
            // 
            lblGiocatore1.AutoSize = true;
            lblGiocatore1.Location = new Point(12, 31);
            lblGiocatore1.Name = "lblGiocatore1";
            lblGiocatore1.Size = new Size(59, 25);
            lblGiocatore1.TabIndex = 0;
            lblGiocatore1.Text = "label1";
            // 
            // lblGiocatore2
            // 
            lblGiocatore2.AutoSize = true;
            lblGiocatore2.Location = new Point(337, 31);
            lblGiocatore2.Name = "lblGiocatore2";
            lblGiocatore2.Size = new Size(59, 25);
            lblGiocatore2.TabIndex = 1;
            lblGiocatore2.Text = "label2";
            // 
            // btnPartitaOK
            // 
            btnPartitaOK.DialogResult = DialogResult.OK;
            btnPartitaOK.Location = new Point(12, 243);
            btnPartitaOK.Name = "btnPartitaOK";
            btnPartitaOK.Size = new Size(554, 89);
            btnPartitaOK.TabIndex = 4;
            btnPartitaOK.Text = "OK";
            btnPartitaOK.UseVisualStyleBackColor = true;
            // 
            // nudG1
            // 
            nudG1.Location = new Point(12, 86);
            nudG1.Name = "nudG1";
            nudG1.Size = new Size(180, 31);
            nudG1.TabIndex = 5;
            // 
            // nudG2
            // 
            nudG2.Location = new Point(337, 86);
            nudG2.Name = "nudG2";
            nudG2.Size = new Size(180, 31);
            nudG2.TabIndex = 6;
            // 
            // FrmDatiPartita
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(578, 344);
            Controls.Add(nudG2);
            Controls.Add(nudG1);
            Controls.Add(btnPartitaOK);
            Controls.Add(lblGiocatore2);
            Controls.Add(lblGiocatore1);
            Name = "FrmDatiPartita";
            Text = "FrmDatiPartita";
            ((System.ComponentModel.ISupportInitialize)nudG1).EndInit();
            ((System.ComponentModel.ISupportInitialize)nudG2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblGiocatore1;
        private Label lblGiocatore2;
        private Button btnPartitaOK;
        public NumericUpDown nudG1;
        public NumericUpDown nudG2;
    }
}