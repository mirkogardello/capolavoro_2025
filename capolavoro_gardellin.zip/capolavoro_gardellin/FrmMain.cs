namespace capolavoro_gardellin;


using System.Drawing.Text;
using System.Text.Json;

public partial class FrmMain : Form
{
    Torneo torneo = new Torneo();


    public FrmMain()
    {
        InitializeComponent();
    }

    private void btnRimuoviGiocatore_Click(object sender, EventArgs e)
    {

        foreach (Giocatore g in lbxGiocatori.SelectedItems)
            torneo.giocatori.Remove(g);
        AggiornaListBoxes();


    }
    public void AggiornaListBoxes()
    {
        lbxGiocatori.Items.Clear();
        foreach (Giocatore g in torneo.giocatori)
            lbxGiocatori.Items.Add(g);
        lbxPartite.Items.Clear();
        foreach (Partita p in torneo.partite)
            lbxPartite.Items.Add(p);

    }

    private void btnGeneraCasuale_Click(object sender, EventArgs e)
    {
        FrmAggiungiPartita f = new FrmAggiungiPartita(torneo.giocatori);

        Random rdn = new Random();
        int a = 0, b = 0, n;
        n = f.lbxScelta1.Items.Count;


        while (n > 1)
        {
            do
            {
                a = rdn.Next(0, n);
                b = rdn.Next(0, n);
            } while (a == b);
            if (a > b)
            {
                a = a + b;
                b = a - b;
                a = a - b;
            }
            Partita p = new Partita(f.lbxScelta1.Items[a] as Giocatore, f.lbxScelta2.Items[b] as Giocatore);
            torneo.AggiungiPartita(p);
            f.lbxScelta1.Items.RemoveAt(b);
            f.lbxScelta2.Items.RemoveAt(b);
            f.lbxScelta1.Items.RemoveAt(a);
            f.lbxScelta2.Items.RemoveAt(a);
            n -= 2;
        }
        AggiornaListBoxes();
        if (n == 1) MessageBox.Show($"Il giocatore {(f.lbxScelta1.Items[0] as Giocatore).Nome} � rimasto senza partita per questo giro.", "ATTENZIONE");

    }

    private void btnRimettiInGioco_Click(object sender, EventArgs e)
    {
        List<Giocatore> lista = new List<Giocatore>();
        for (int i = 0; i < lbxGiocatori.SelectedItems.Count; i++) (lbxGiocatori.SelectedItems[i] as Giocatore).Stato = true;
        for (int i = 0; i < torneo.giocatori.Count; i++)
        {
            torneo.giocatori[i].CambiaStato((lbxGiocatori.Items[i] as Giocatore).Stato);
        }
        AggiornaListBoxes();
    }

    private void btnAggiungiGiocatore_Click(object sender, EventArgs e)
    {
        FrmAggiungiGiocatore f = new FrmAggiungiGiocatore();
        if (f.ShowDialog() != DialogResult.OK) return;
        try
        {
            Giocatore g = new Giocatore(f.txtNome.Text, f.txtDescrizione.Text);
            torneo.AggiungiGiocatore(g);
            AggiornaListBoxes();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Errore nella creazione di un giocatore");
        }
    }

    private void btnInserisciManualmente_Click(object sender, EventArgs e)
    {
        FrmAggiungiPartita f = new FrmAggiungiPartita(torneo.giocatori);
        if (f.ShowDialog() != DialogResult.OK) return;
        try
        {
            Partita p = new Partita(f.lbxScelta1.SelectedItem as Giocatore, f.lbxScelta2.SelectedItem as Giocatore);
            torneo.AggiungiPartita(p);
            AggiornaListBoxes();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Errore nell'inserimento della partita");
        }
    }

    private void btnRimuoviPartite_Click(object sender, EventArgs e)
    {

        foreach (Partita p in lbxPartite.SelectedItems)
        {
            torneo.RimuoviPartita(p);
        }
        AggiornaListBoxes();
    }

    private void btnChiudiPartita_Click(object sender, EventArgs e)
    {
        if (lbxPartite.SelectedItems.Count != 1) return;
        int indice = lbxPartite.SelectedIndex;
        FrmDatiPartita f = new FrmDatiPartita(lbxPartite.SelectedItem as Partita);
        if (f.ShowDialog() != DialogResult.OK) return;
        try
        {
            int a, b;
            a = (int)f.nudG1.Value;
            b = (int)f.nudG2.Value;
            f.p.CambiaRisultato(a, b);
            if (a > b)
            {
                torneo.RimuoviDalGioco(f.p.g2);
            }
            else if (b > a)
            {
                torneo.RimuoviDalGioco(f.p.g1);
            }
            torneo.partite[indice] = f.p;

            AggiornaListBoxes();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Errore nella chiusura della partita");
        }
    }

    private void btnCarica_Click(object sender, EventArgs e)
    {
        if (ofdApri.ShowDialog() != DialogResult.OK) return;
        string path = ofdApri.FileName;
        if (path.Length < 6 || path.Substring(path.Length - 5) != ".json")
        {
            MessageBox.Show("Devi selezionare un file .json", "ESTENSIONE FILE ERRATA");
            return;
        }
        torneo = JsonSerializer.Deserialize<Torneo>(File.ReadAllText(path));
        AggiornaListBoxes();

    }

    private void btnSalva_Click(object sender, EventArgs e)
    {
        if (sfdSalva.ShowDialog() != DialogResult.OK) return;
        string path = sfdSalva.FileName;
        if (path.Length < 6 || path.Substring(path.Length - 5) != ".json")
        {
            path += ".json";
        }
        string json = JsonSerializer.Serialize(torneo, new JsonSerializerOptions { WriteIndented = true });
        File.WriteAllText(path, json);

    }

    private void btnPulisci_Click(object sender, EventArgs e)
    {
        if (MessageBox.Show("Sei sicuro di voler pulire il torneo?", "ATTENZIONE", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;
        torneo = new Torneo();
        AggiornaListBoxes();
    }

    private void btnVisualizzaDatiGiocatore_Click(object sender, EventArgs e)
    {
        if (lbxGiocatori.SelectedItems.Count != 1) return;
        Giocatore g = lbxGiocatori.SelectedItem as Giocatore;
        MessageBox.Show($"Nome : {g.Nome}\nStato : {g.StatoToString()}\nDescrizione : {g.Info}", "Dati del giocatore");
    }

    private void btnVisualizzaDatiPartita_Click(object sender, EventArgs e)
    {
        if(lbxPartite.SelectedItems.Count != 1) return;
        Partita p = lbxPartite.SelectedItem as Partita;
        MessageBox.Show($"Giocatore 1 : {p.g1.Nome}\nGiocatore 2 : {p.g2.Nome}\nRisultato : {p.Risultato}", "Dati della partita");
    }
}

