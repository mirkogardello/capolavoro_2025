﻿namespace capolavoro_gardellin
{
    partial class FrmAggiungiPartita
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lbxScelta1 = new ListBox();
            lblVS = new Label();
            lbxScelta2 = new ListBox();
            btnConfermaPartita = new Button();
            SuspendLayout();
            // 
            // lbxScelta1
            // 
            lbxScelta1.FormattingEnabled = true;
            lbxScelta1.ItemHeight = 25;
            lbxScelta1.Location = new Point(12, 9);
            lbxScelta1.Name = "lbxScelta1";
            lbxScelta1.Size = new Size(273, 429);
            lbxScelta1.TabIndex = 0;
            // 
            // lblVS
            // 
            lblVS.AutoSize = true;
            lblVS.Font = new Font("Segoe UI", 20F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblVS.Location = new Point(318, 176);
            lblVS.Name = "lblVS";
            lblVS.Size = new Size(69, 54);
            lblVS.TabIndex = 2;
            lblVS.Text = "VS";
            // 
            // lbxScelta2
            // 
            lbxScelta2.FormattingEnabled = true;
            lbxScelta2.ItemHeight = 25;
            lbxScelta2.Location = new Point(417, 12);
            lbxScelta2.Name = "lbxScelta2";
            lbxScelta2.Size = new Size(273, 429);
            lbxScelta2.TabIndex = 3;
            // 
            // btnConfermaPartita
            // 
            btnConfermaPartita.DialogResult = DialogResult.OK;
            btnConfermaPartita.Font = new Font("Segoe UI Black", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnConfermaPartita.Location = new Point(295, 352);
            btnConfermaPartita.Name = "btnConfermaPartita";
            btnConfermaPartita.Size = new Size(112, 86);
            btnConfermaPartita.TabIndex = 4;
            btnConfermaPartita.Text = "OK";
            btnConfermaPartita.UseVisualStyleBackColor = true;
            // 
            // FrmAggiungiPartita
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(703, 450);
            Controls.Add(btnConfermaPartita);
            Controls.Add(lbxScelta2);
            Controls.Add(lblVS);
            Controls.Add(lbxScelta1);
            Name = "FrmAggiungiPartita";
            Text = "Aggiunta manuale della partita";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        public ListBox lbxScelta1;
        private Label lblVS;
        public ListBox lbxScelta2;
        private Button btnConfermaPartita;
    }
}